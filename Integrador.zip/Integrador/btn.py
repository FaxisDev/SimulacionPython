import Integrador
import sys
import math
import tkMessageBox
from Tkinter import *

lista = []

def funcion_del_boton():
    try:
        intervalos_generados = [0]
        x0_generados = int(entrada_de_datos.get())
        a = int(entrada_de_datos2.get())
        m = int(entrada_de_datos3.get())

        #funciones
        i = 1
        x1 = 0
        llegada = x0_generados
        over = ""

    

        while not llegada == x1:
            x1 = ((x0_generados)*(a)) % m
            r = float(x1) / m
            lista.append(r)
            x0_generados = x1
            i += 1
        x1 = ((x0_generados)*(a)) % m
        r = float(x1) / m

        n = lista.__len__()
        m = round(math.sqrt(n))

        m3 = Label(Integrador.pyfr, text="Raiz M: {}".format(m),bg="#45B7E7")
        m3.grid(column=1, row=7, sticky=(W,E))

        intervalo = 1/m
        ei = (n/m)
        rectas = 0

        while rectas <= 1:
            intervalos_sub = 0
            conta = 0
            while conta < n:
                if (lista[conta] >= rectas) and (lista[conta] <= (rectas + intervalo)):
                    intervalos_sub += 1
                conta += 1
            if not (rectas + intervalo) > 1:
                intervalos_generados.append(intervalos_sub)
            rectas = rectas + intervalo

        rectas = 0
        conta = 1
        x_suma = 0

        texto = Label(Integrador.pyfr, text="Rango", bg="#F95623")
        texto.grid(column=1, row=10, sticky=(W,E))
        
        texto = Label(Integrador.pyfr, bg="#F3D525",text="Io ")
        texto.grid(column=2, row=10, sticky=(W,E))

        texto = Label(Integrador.pyfr, bg="#3BD728",text="Ei = (n/m)")
        texto.grid(column=3, row=10, sticky=(W,E))

        texto = Label(Integrador.pyfr, bg="#31F8B3",text="X! = (Ei - Io)^2 / Ei")
        texto.grid(column=4, row=10, sticky=(W,E))

        texto = Label(Integrador.pyfr, bg="#30B1FA",text="Numero de Corridas (Co)")
        texto.grid(column=4, row=11, sticky=(W,E))

        while rectas + intervalo <= 1:
            xri = (pow((ei - intervalos_generados[conta]),2)) / ei
            x_suma = x_suma + xri

            inter = " {} - {}".format(rectas,(rectas + intervalo))
            texto = Label(Integrador.pyfr, bg="#F6A32A",text=inter)
            texto.grid(column=1, row=(10+conta), sticky=(W,E))

            io_var = intervalos_generados[conta]
            texto = Label(Integrador.pyfr, bg="#D0EC2B",text=io_var)
            texto.grid(column=2, row=(10+conta), sticky=(W,E))

            texto = Label(Integrador.pyfr, bg="#3AA7E1",text=ei)
            texto.grid(column=3, row=(10+conta), sticky=(W,E))

            texto = Label(Integrador.pyfr, bg="#8953E4",text=xri)
            texto.grid(column=4, row=(10+conta), sticky=(W,E))

            conta += 1
            rectas = rectas + intervalo

        texto = Label(Integrador.pyfr, bg="#DE8B2C",text="Total: {} ".format(x_suma))
        texto.grid(column=1, row=(10+conta+1), sticky=(W,E))

        #codigo corridas! 
        ri = lista
        bin = []
        n = ri.__len__()
        n1 = 0
        n0 = 0
        co = 0

        cont = 0
        while cont < n:
            if ri[cont] <= 0.50:
                n0 = n0 + 1
                bin.append(0)
            else:
                n1 = n1 + 1
                bin.append(1)
            cont += 1

        cont = 0
        while cont < n:
            if (bin[cont] == 1 and bin[cont - 1] != 1) or (bin[cont] == 1 and cont == 0):
                co = co + 1
            elif (bin[cont] == 0 and bin[cont - 1] != 0) or (bin[cont] == 0 and cont == 0):
                co = co + 1
            cont += 1

        texto = Label(Integrador.pyfr,fg="#ffffff", bg="#0A9EFA",text="Numero de ri (n): {} ".format(n), borderwidth=0, width=10)
        texto.grid(column=1, row=(11+conta+1), sticky="nsew")

        texto = Label(Integrador.pyfr,fg="#ffffff", bg="#529DCC",text="Numeros de 0's (n0): {} ".format(n0))
        texto.grid(column=1, row=(12+conta+1), sticky=(W,E))

        texto = Label(Integrador.pyfr,fg="#ffffff", bg="#285978",text="Numeros de 1's (n1): {} ".format(n1))
        texto.grid(column=1, row=(13+conta+1), sticky=(W,E))

        texto = Label(Integrador.pyfr,fg="#ffffff", bg="#11212B",text="conjunto: {} ".format(bin))
        texto.grid(column=1, row=(14+conta+1), sticky=(W,E))

        #Formula Para sacar valor Esperado (Mco)
        Mco = (2*n0*n1/float(n)) + (1/float(2))
        texto = Label(Integrador.pyfr,fg="#2B3809", bg="#CCF364",text="Valor Esperado (Mco): {} ".format(Mco))
        texto.grid(column=3, row=(11+conta+1), sticky=(W,E))

        #Formula  para sacar la varianza
        O2Co = ((float(2*n0*n1))*((float(2*n0*n1))-n))/((math.pow(n,2))*(n-1))
        texto = Label(Integrador.pyfr,fg="#2B3809", bg="#ABC56A",text="Valor de la Varianza (O2Co): {} ".format(O2Co))
        texto.grid(column=3, row=(12+conta+1), sticky=(W,E))

        #formula para sacar la Estadistica
        lo = (((co)-(Mco)))/(math.sqrt(O2Co))
        texto = Label(Integrador.pyfr,fg="#2B3809", bg="#7F9449",text="El valor de la Estadistica (Lo): {} ".format(lo))
        texto.grid(column=3, row=(13+conta+1), sticky=(W,E))

        texto = Label(Integrador.pyfr,fg="#340502", bg="#ED5048",text="Ri Generados: ")
        texto.grid(column=4, row=(10+conta+1), sticky=(W,E))

        h = 0
        while h < lista.__len__():
            texto = Label(Integrador.pyfr,fg="#ffffff", bg="#B81429",text="{} - {} ".format((h+1),lista[h]))
            texto.grid(column=4, row=(11+conta+1+h), sticky=(W,E))
            h += 1

        boton = Button(Integrador.pyfr, text="Generar Poker", command=poker_face,font=("trebuchet ms", 14))
        boton.grid(column=1, row=(15+conta+1))

        poker_datos = Spinbox(Integrador.pyfr, from_=90, to=95, width=5, textvariable="")
        poker_datos.grid(column=2, row=(15+conta+1))

        global datos_poker
        datos_poker = poker_datos.get()
        global grid_poker
        grid_poker = 15+conta+1

    except ValueError:
        tkMessageBox.showinfo('Error', 'Ingresaste texto en ves de numeros :(')

conj_ri = lista

conjunto_90_poker = {
	1:2.706,2:4.605,3:6.251,4:7.779,5:9.236,6:10.645,7:12.017,8:13.362,9:14.684,10:15.987,
	11:17.275,12:18.549,13:19.812,14:21.064,15:22.307,16:23.542,17:24.769,18:25.989,19:27.204,20:28.412,
	21:29.615,22:30.813,23:32.007,24:33.196,25:34.382,26:35.563,27:36.741,28:37.916,29:39.087,30:40.256,
	40:51.805,50:63.167,60:74.397,70:85.527,80:96.578,90:107.565,100:118.498
	       }
conjunto_95_poker = {
	1:3.841,2:5.991,3:7.815,4:9.488,5:11.070,6:12.592,7:14.067,8:15.507,9:16.919,10:18.307,
	11:19.675,12:21.026,13:22.362,14:23.685,15:24.996,16:26.296,17:27.587,18:28.869,19:30.144,20:31.410,
	21:32.671,22:33.924,23:35.172,24:36.415,25:37.652,26:38.885,27:40.113,28:41.337,29:42.557,30:43.773,
	40:55.758,50:67.505,60:79.082,70:90.531,80:101.879,90:113.145,100:124.342
	       }

num_Poker4 = [0.5040,0.4320,0.0270,0.0360,0.0010]

def pruebaChi_independencia(estadistico,m):
    xa = m - 1
    texto = Label(Integrador.pyfr,fg="#340502", bg="#ED5048",text="Valor Estadistico: {} ".format(str(estadistico)))
    texto.grid(column=1, row=(grid_poker+1), sticky=(W,E))

    texto = Label(Integrador.pyfr,fg="#340502", bg="#F76E34",text="M - 1: {} ".format(str(xa)))
    texto.grid(column=2, row=(grid_poker+1), sticky=(W,E))

    confi = int(datos_poker)

    valor_chi = 0
    if(confi == 95):
        valor_chi = conjunto_95_poker[xa]
        texto = Label(Integrador.pyfr,fg="#340502", bg="#F6AD0F",text="Valor Chi: {} ".format(valor_chi))
        texto.grid(column=2, row=(grid_poker+2), sticky=(W,E))
        if(conjunto_95_poker[xa] > estadistico):
            texto = Label(Integrador.pyfr,fg="#340502", bg="#F78AB2",text=" {} > {} || Se acepta que el conjunto ri es independiente".format(conjunto_95_poker[xa],estadistico))
            texto.grid(column=1, row=(grid_poker+2), sticky=(W,E))
        else:
            texto = Label(Integrador.pyfr,fg="#340502", bg="#F78AB2",text=" {} < {} || NO * Se acepta que el conjunto ri es independiente".format(conjunto_95_poker[xa],estadistico))
            texto.grid(column=1, row=(grid_poker+2), sticky=(W,E))
    if(confi == 90):
        valor_chi = conjunto_90_poker[xa]
        texto = Label(Integrador.pyfr,fg="#340502", bg="#F6AD0F",text="Valor Chi: {} ".format(valor_chi))
        texto.grid(column=2, row=(grid_poker+2), sticky=(W,E))
        if(conjunto_90_poker[xa] > estadistico):
            texto = Label(Integrador.pyfr,fg="#340502", bg="#F78AB2",text=" {} > {} || Se acepta que el conjunto ri es independiente".format(conjunto_90_poker[xa],estadistico))
            texto.grid(column=1, row=(grid_poker+2), sticky=(W,E))
        else:
            texto = Label(Integrador.pyfr,fg="#340502", bg="#F78AB2",text=" {} < {} || NO * Se acepta que el conjunto ri es independiente".format(conjunto_90_poker[xa],estadistico))
            texto.grid(column=1, row=(grid_poker+2), sticky=(W,E))

def funcion_cadena_a_entero(num_str):
    arm = ''+str(num_str)
    while (len(arm) < 4):
        arm = arm + '0'
    i,k = 0,[]
    while(i < len(arm)):
        k.append(int(arm[i]))
        i = i + 1
    l,n = 0,0
    while(l < len(k)):
        n = 0
        while(n < len(k)):
            if(k[l] < k[n]):
                aux = k[l]
                no = k[n]
                k[n] = aux
                k[l] = no
            n = n + 1
        l = l + 1
    return k

#funcion que reorganiza la lista de caracteres y acomoda los caracteres en pares, triadas y diferentes.
def poker_elementos(os):
    mmo, exo,dt = '',0,''
    for al in os:
        mmo = mmo + str(al)
    while exo < len(os):
        if int(mmo[exo-1]) != int(mmo[exo]):
            dt = dt + ' '
        dt = dt + mmo[exo]
        exo = exo + 1
    return dt.split()

#funcion que asigna la clasificasion a la lista de caracteres
def Asigna_clasific(li):
 nn = ''
 if len(li) == 4:
  nn = 'TD'
 elif len(li) == 3:
  nn = '1P'
 elif len(li) == 2:
  per1,per2 = str(li[0]),str(li[1])
  if len(per1) == 2 and len(per2) == 2:
    nn = '2P'
  else:
    nn = 'T'
 elif len(li) == 1:
  nn = 'PK'
 return nn

#caos
def Casos(num):
    az = funcion_cadena_a_entero(num)
    ver = poker_elementos(az)
    tx = Asigna_clasific(ver)
    return tx

def Convertir_string(ri):
    conj_str,conj_casif = [],[]
    for i in ri:
        string = str(i)
        conj_str.append(string[2:6])
    for letra in conj_str:
        conj_casif.append(Casos(letra))

    texto = Label(Integrador.pyfr,fg="#340502", bg="#448DF3",text="Conjunto Clasificador: {}".format(conj_casif))
    texto.grid(column=1, row=(grid_poker+3), sticky=(W,E))     
    return conj_casif

#funcion que contaviliza los casos
def conteo_casos(emm):
    TD,P,P2,T,PK = 0,0,0,0,0
    for k in emm:
        if 'TD' == k:
            TD = TD + 1
        elif '1P' == k:
            P = P + 1
        elif 'T' == k:
            T = T + 1
        elif '2P' == k:
            P2 = P2 + 1
        elif 'PK' == k:
            PK = PK + 1
    return [TD,P,P2,T,PK]
#funcion que realiza el calculo para obtener el estadistico
def calculo(valores,conteo,num_datos):
    texto = Label(Integrador.pyfr,fg="#340502", bg="#A7E65E",text="Conteo: {}".format(conteo))
    texto.grid(column=2, row=(grid_poker+3), sticky=(W,E))
    est,chi,j,i = [],[],0,0
    while (i < len(conteo)):
        ei = round(float(valores[i] * num_datos),4)
        x = round(float(pow(ei-conteo[j],2)/ei),4)
        est.append(ei)
        chi.append(x)
        j += 1
        i += 1
    texto = Label(Integrador.pyfr,fg="#340502", bg="#B89BE0",text="Ji-Cuadrada: {}".format(chi))
    texto.grid(column=1, row=(grid_poker+4), sticky=(W,E))
    texto = Label(Integrador.pyfr,fg="#340502", bg="#61DAAE",text="Estadistica: {}".format(est))
    texto.grid(column=2, row=(grid_poker+4), sticky=(W,E))
    suma = 0
    for val in chi:
        suma = suma + val
    pruebaChi_independencia(suma,len(chi))
#funcion que da inicio a la prueba mandadno a llamar a las funciones
#Comvertir_string, conteo_casosy calculo.
def inicio_poker(datos):
    a = Convertir_string(datos)
    b = conteo_casos(a)
    c = num_Poker4
    d = len(datos)
    e = calculo(c,b,d)


def poker_face():
    try:
        inicio_poker(lista)
    except ValueError:
        tkMessageBox.showinfo('Error', 'No ingresaste el porcentaje')


