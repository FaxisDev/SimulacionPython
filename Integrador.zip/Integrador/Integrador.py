import btn
import sys
import math
from Tkinter import *

app = Tk()
app.title("Semilla Lineal + Chicuadrada + Corridas")

pyfr = Frame(app)
pyfr.grid(column=0, row=0, padx=(10,10), pady=(10,10))

lista_ocurrencias = Label(pyfr, text="")
lista_ocurrencias.grid(column=5, row=5,)
 
boton = Button(pyfr, text="+ Correr", command=btn.funcion_del_boton,font=("trebuchet ms", 14))
boton.grid(column=4, row=1,padx=(10,22), pady=(10,10),sticky=(W,E))


# Entrada de datos con spin

texto = Label(pyfr, text="x0:")
texto.grid(column=1, row=0, sticky=(W,E))
default_valor = ""

btn.entrada_de_datos = Spinbox(pyfr, from_=23, to=1000, width=5, textvariable=default_valor)
btn.entrada_de_datos.grid(column=1, row=1)

texto = Label(pyfr, text="A:")
texto.grid(column=2, row=0, sticky=(W,E))

btn.entrada_de_datos2 = Spinbox(pyfr, from_=17, to=1000, width=5, textvariable=default_valor)
btn.entrada_de_datos2.grid(column=2, row=1)

texto = Label(pyfr, text="M:")
texto.grid(column=3, row=0, sticky=(W,E))

btn.entrada_de_datos3 = Spinbox(pyfr, from_=31, to=1000, width=5, textvariable=default_valor)
btn.entrada_de_datos3.grid(column=3, row=1)



xscrollbar = Scrollbar(pyfr, orient=HORIZONTAL)
xscrollbar.grid(row=1, column=0, sticky=E+W)

yscrollbar = Scrollbar(pyfr)
yscrollbar.grid(row=0, column=1, sticky=N+S)

canvas = Canvas(pyfr, bd=0, scrollregion=(0, 0, 1000, 1000),
                xscrollcommand=xscrollbar.set,
                yscrollcommand=yscrollbar.set)

xscrollbar.config(command=canvas.xview)
yscrollbar.config(command=canvas.yview)

canvas.grid(row=0, column=0, sticky=N+S+E+W)
f=Frame(canvas)
f.pack()
app.mainloop()